module.exports = {
	"development": 0,
	"staging": 1,
	"production": 2
}