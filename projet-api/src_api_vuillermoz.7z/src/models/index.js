const UserModel = require("./UtilisateurModel");
const MessageModel = require("./MessageModel");

module.exports = {
	User: UserModel,
	Message: MessageModel,
};



//This is just a comment. Without any utility. But you've lost 4 seconds to read it entirely. Kiss